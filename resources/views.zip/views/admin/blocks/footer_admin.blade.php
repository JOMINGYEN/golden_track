<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                2020 - 2021 &copy; Minton theme by <a href="#">Coderthemes</a>
            </div>
            <div class="col-md-6">
                <div class="text-md-right footer-links d-none d-sm-block">
                    <a href="{{URL::to('/about-us')}}">Cửa hàng</a>
                </div>
            </div>
        </div>
    </div>
</footer>
