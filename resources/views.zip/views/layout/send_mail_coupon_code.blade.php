<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>SHOES SHOP</title>
</head>
<body>
    <h3>Thư Gửi Từ: {{ $name }}</h3>
    <h4>Gửi Bạn Mã Khuyến Mãi</h4>
    <h5>Mã Khuyến Mãi: <span> {{ $code }}</span></h5>
    <h5>Nội Dung Khuyến Mãi: <span> {{ $name_code }}</span></h5>
    <h5>Cám Ơn Đã Mua Hàng!</h5>
</body>
</html>
